package uk.ac.standrews.cs.cs3099.useri.risk.protocol.commands;

public class DeployTuple{
    public int territory, armies;
    public DeployTuple(int territory, int armies){
        this.territory = territory;
        this.armies = armies;
    }
}