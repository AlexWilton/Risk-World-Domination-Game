package uk.ac.standrews.cs.cs3099.useri.risk.protocol.exceptions;

import java.io.IOException;

/**
 * Created by bs44 on 14/04/15.
 */
public class RollException extends IOException {
}
