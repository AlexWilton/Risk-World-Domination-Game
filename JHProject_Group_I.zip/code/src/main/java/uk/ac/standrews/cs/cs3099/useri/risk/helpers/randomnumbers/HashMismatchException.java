package uk.ac.standrews.cs.cs3099.useri.risk.helpers.randomnumbers;

public class HashMismatchException extends Exception {

	private static final long serialVersionUID = 1L;

	public HashMismatchException(String message)
	{
		super(message);
	}

}
