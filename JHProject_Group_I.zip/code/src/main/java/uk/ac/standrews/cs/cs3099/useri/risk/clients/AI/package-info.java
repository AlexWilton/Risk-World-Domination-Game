/**
 * AI are clients which can play without requiring any user input
 */
package uk.ac.standrews.cs.cs3099.useri.risk.clients.AI;