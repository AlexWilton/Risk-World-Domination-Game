package uk.ac.standrews.cs.cs3099.useri.risk.game;

/**
 * Created by 120010447 on 16/04/15.
 */
import org.junit.*;
import uk.ac.standrews.cs.cs3099.useri.risk.game.gameModel.RiskCard;

/**
 * Test Class to do small unit tests on multiple misc classes
 */
public class MiscUnitTest {

    RiskCard testCard;

    @Test
    public void testRiskCard(){
        //testCard = new RiskCard();

    }

}
