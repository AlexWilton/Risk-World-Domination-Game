/**
 * Classes necessary to support the Web Client
 */
package uk.ac.standrews.cs.cs3099.useri.risk.clients.webClient;