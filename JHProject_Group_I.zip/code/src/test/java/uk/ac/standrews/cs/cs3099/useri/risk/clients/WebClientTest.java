package uk.ac.standrews.cs.cs3099.useri.risk.clients;

import org.junit.Test;

import static org.junit.Assert.*;

public class WebClientTest {

    @Test
    public void testGetDefenders() throws Exception {

    }
}