/**
 * Contains all Clients (AI, Web Clients and Terminal Clients)
 */
package uk.ac.standrews.cs.cs3099.useri.risk.clients;