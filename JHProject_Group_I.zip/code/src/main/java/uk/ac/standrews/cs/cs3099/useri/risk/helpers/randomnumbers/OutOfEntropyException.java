package uk.ac.standrews.cs.cs3099.useri.risk.helpers.randomnumbers;

public class OutOfEntropyException extends Exception {

	private static final long serialVersionUID = 1L;

	public OutOfEntropyException(String message)
	{
		super(message);
	}

}
