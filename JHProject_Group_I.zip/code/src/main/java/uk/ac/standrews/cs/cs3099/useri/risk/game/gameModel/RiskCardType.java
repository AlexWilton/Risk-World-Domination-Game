package uk.ac.standrews.cs.cs3099.useri.risk.game.gameModel;

/**
 * Different types of Risk cards.
 * @author bs44
 *
 */
public enum RiskCardType { 
	
	TYPE_CAVALRY, TYPE_ARTILLERY, TYPE_INFANTRY, TYPE_WILDCARD

}
