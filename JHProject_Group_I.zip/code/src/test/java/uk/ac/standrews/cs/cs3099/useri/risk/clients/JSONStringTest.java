package uk.ac.standrews.cs.cs3099.useri.risk.clients;

import org.junit.Before;
import org.junit.Test;
import uk.ac.standrews.cs.cs3099.useri.risk.game.State;
import uk.ac.standrews.cs.cs3099.useri.risk.testHelper.TestGameStateFactory;

/**
 * Created by 120010447 on 11/04/15.
 */

public class JSONStringTest {
    private State testState;

    @Before
    public void setup(){
        testState = TestGameStateFactory.getTestGameState();
    }


    @Test
    public void mapToJSONStringTest(){
        //assertTrue(false);
    }

    @Test
    public void countryToJSONStringTest(){
        //assertTrue(false);
    }

}
